# CareAI — Bản source tổng hợp để chia sẻ

Bản tổng hợp ngày 25/09/2026, lấy từ dự án đang chạy tại CareAI-main - Copy. Bao gồm nhiệm vụ 4.1–4.5, bản sửa Flutter web bị màn hình trắng và CORS cho frontend localhost:8080 gọi backend localhost:5097.

Đây là **toàn bộ source dự án**, không phải gói patch. Người nhận giải nén vào một thư mục mới để xem/chạy, không cần ZIP gốc hay các gói cập nhật cũ.

## Cấu trúc

```text
CareAI/
  CareAI.slnx
  src/
    CareAI.Core/             Entity, DTO, enum
    CareAI.Infrastructure/   EF Core, ML.NET, Gemini, fallback, workers
    CareAI.API/              API, authentication, đăng ký DI và CORS
  tests/CareAI.UnitTests/    Bộ kiểm thử backend
  companion_app/            Flutter, giao diện người thân và thiết bị
docs/                       Hướng dẫn kỹ thuật nhiệm vụ 4
```

## Những gì đã có

- Phân tích nhịp tim trung bình ban đêm và zero-step buổi sáng; lưu HealthInsights.
- Payload Gemini chỉ gồm các trường thống kê số, không gửi định danh/ghi chú gốc.
- Báo cáo tuần tiếng Việt; fallback nội bộ khi AI không khả dụng.
- Lưu báo cáo, hàng đợi thông báo Firebase và kiểm tra quyền truy cập.
- Góc Sức Khỏe AI: nhận định, lịch sử và chi tiết báo cáo.
- Web mở giao diện người thân, bỏ qua SQLite/Workmanager vốn dành cho thiết bị di động khi khởi động.
- CORS Development cho http://localhost:8080 và http://127.0.0.1:8080.

## Chạy trên máy người nhận

Cài .NET SDK 9, Flutter SDK phù hợp với sdk constraint trong companion_app/pubspec.yaml, Edge và SQL Server/SQL Server Express (hoặc Azure SQL riêng). VS Code là tùy chọn.

Mở terminal tại thư mục `CareAI` có file CareAI.slnx.

### 1. Kiểm tra backend bằng test, chưa cần database thật

```powershell
dotnet restore CareAI.slnx
dotnet build CareAI.slnx
dotnet test tests/CareAI.UnitTests/CareAI.UnitTests.csproj
```

### 2. Chuẩn bị database

Tạo database `CareAiDb` trong SQL Server của người nhận (ví dụ bằng SQL Server Management Studio). Tài khoản chạy backend cần quyền kết nối và tạo bảng/index. DatabaseMigrationHelper tự tạo bảng khi khởi động, nhưng **không tạo database/server**.

Mặc định appsettings.json dùng SQL Server Express với Windows Authentication:

```text
Server=.\SQLEXPRESS;Database=CareAiDb;Integrated Security=True;TrustServerCertificate=True;
```

Nếu dùng server khác, đặt biến môi trường trong terminal backend:

```powershell
$env:ConnectionStrings__DefaultConnection="<CHUOI_KET_NOI_DATABASE_CUA_NGUOI_NHAN>"
```

Không dán nguyên dấu `<...>`; thay bằng cấu hình thực tế. Không dùng database của người gửi khi chưa được cấp quyền.

### 3. Tạo khóa JWT riêng và chạy backend

```powershell
$jwtBytes = New-Object byte[] 48
$jwtRandom = [System.Security.Cryptography.RandomNumberGenerator]::Create()
$jwtRandom.GetBytes($jwtBytes)
$env:Jwt__SecretKey = [Convert]::ToBase64String($jwtBytes)
$jwtRandom.Dispose()
$env:ASPNETCORE_ENVIRONMENT="Development"
dotnet run --project src/CareAI.API/CareAI.API.csproj --launch-profile http
```

Giữ terminal mở. Khóa trên tạo mới mỗi lần chạy đoạn script; token cũ sẽ hết hiệu lực nếu đổi khóa. Môi trường triển khai cần giữ khóa riêng trong cấu hình bí mật.

Kiểm tra:

- http://localhost:5097/health → Healthy: tiến trình API phản hồi, **không xác nhận database đã kết nối**.
- http://localhost:5097/swagger/index.html → Swagger.
- Kiểm tra log DB-INIT thành công; STARTUP-WARNING liên quan database cần xử lý trước khi đăng ký/đăng nhập.

### 4. Chạy giao diện ở terminal thứ hai

Vào thư mục companion_app của bản vừa giải nén:

```powershell
flutter pub get
flutter run -d edge --web-port 8080
```

Đợi Edge tự mở http://localhost:8080 và giữ cả hai terminal chạy. Không mở cổng ngẫu nhiên của lần chạy cũ.

Trong biểu tượng bánh răng trên màn hình đăng nhập, đặt server là `http://127.0.0.1:5097`. Đăng ký tài khoản mới, tạo/liên kết hồ sơ người cao tuổi, mở hồ sơ rồi chọn Góc Sức Khỏe AI.

Database mới không có tài khoản, số đo hay báo cáo của người gửi. Danh sách rỗng khi chưa có dữ liệu là bình thường. Nhận định ML cần đủ lịch sử đo; không có dữ liệu không được coi là 0 bước.

### 5. Gemini và Firebase là cấu hình tùy chọn

Không có Gemini key vẫn tạo được báo cáo bằng quy tắc nội bộ. Firebase mặc định tắt; app vẫn xem báo cáo qua API nhưng chưa nhận thông báo đẩy. Xem docs/README-part4.md để cấu hình tài khoản riêng.

Thông tin cấu hình mẫu trong gói chỉ dùng để phát triển; không dùng khóa JWT mẫu hoặc cấu hình local cho hệ thống public.

## Kiểm thử và giới hạn

- Trong đợt triển khai phần 4 trước đó: backend build thành công và 73/73 test đạt; báo cáo coverage cũ được kèm trong docs, không phải kết quả chạy lại trên bản đóng gói này.
- Người gửi đã xác nhận chạy được sau khi áp dụng sửa web/CORS. Bản chia sẻ đã thay cấu hình bí mật và địa chỉ máy riêng; chưa build lại toàn bộ bản chia sẻ hoặc chạy với database của người nhận.
- Ba widget test Flutter đã được viết. Chưa xác nhận Flutter analyze, build APK/iOS hoặc gửi Firebase/Gemini thật trong lần đóng gói này.
- Phát hiện ML hiện đánh giá trung bình đêm, không bắt mọi spike ngắn từng mẫu. Fallback không chờ thêm I/O nhưng không bảo đảm xử lý đúng 0ms.
- Web dùng phần người thân; các chức năng cảm biến, SQLite và tác vụ nền của thiết bị cần môi trường di động phù hợp.

## Thay đổi riêng để chia sẻ

- Thay appsettings bằng cấu hình SQL Express mẫu, bỏ credential Azure SQL và JWT của bản đang chạy.
- Không kèm database, secret cá nhân, thư mục build/cache, file backup và đường dẫn SDK máy người gửi.
- Thay endpoint tunnel/IP LAN được hardcode trong hai API service bằng localhost. Người nhận chọn địa chỉ server riêng trong ứng dụng.
- Mã nguồn còn lại lấy từ bản trên ổ đĩa; thay đổi chưa lưu trong VS Code không thể nằm trong gói.

FILE-MANIFEST.csv ghi danh sách file và SHA-256 để đối chiếu.
