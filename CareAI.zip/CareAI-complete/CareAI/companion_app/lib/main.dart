import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:workmanager/workmanager.dart';
import 'caregiver/screens/home_screen.dart';
import 'caregiver/screens/login_screen.dart';
import 'caregiver/services/caregiver_api_service.dart';
import 'screens/device_pairing_screen.dart';
import 'screens/role_selection_screen.dart';
import 'screens/sos_button_screen.dart';
import 'services/api_service.dart';
import 'services/local_offline_store.dart';
import 'services/sync_service.dart';

@pragma('vm:entry-point')
void callbackDispatcher() {
  Workmanager().executeTask((taskName, inputData) async {
    try {
      // Tác vụ đồng bộ nền định kỳ 15 phút (UC-03 Offline-to-Online Batch Sync)
      final result = await SyncService.instance.syncOfflineSpool();
      debugPrint('[CareAI-Workmanager] Đã đồng bộ nền thành công: ${result.syncedCount} gói tin');
      return true;
    } catch (e) {
      debugPrint('[CareAI-Workmanager] Lỗi đồng bộ nền: $e');
      return false;
    }
  });
}

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // The browser only runs the caregiver UI. Native SQLite and Workmanager
  // initialization below remains unchanged for mobile devices.
  if (kIsWeb) {
    try {
      await CaregiverApiService.instance.init();
      final loggedIn = await CaregiverApiService.instance.isLoggedIn();
      runApp(CareAiUnifiedApp(
        initialScreen: loggedIn ? const HomeScreen() : const LoginScreen(),
      ));
    } catch (error, stack) {
      debugPrint('Web startup failed: $error\n$stack');
      runApp(const MaterialApp(
        home: Scaffold(body: Center(child: Text(
          'Không thể khởi động. Hãy kiểm tra quyền lưu trữ của trình duyệt và tải lại trang.',
          textAlign: TextAlign.center,
        ))),
      ));
    }
    return;
  }

  // 1. Khởi tạo CSDL SQLite Outbox Spool
  await LocalOfflineStore.instance.database;

  // 2. Khởi tạo Dịch vụ Người Thân (SharedPreferences & Server URL)
  await CaregiverApiService.instance.init();

  // 3. Khởi tạo Workmanager để đồng bộ nền thiết bị
  try {
    await Workmanager().initialize(
      callbackDispatcher,
    );

    await Workmanager().registerPeriodicTask(
      'careai_periodic_sync_task',
      'careai_periodic_sync',
      frequency: const Duration(minutes: 15),
      constraints: Constraints(
        networkType: NetworkType.connected,
      ),
    );
  } catch (e) {
    debugPrint('Không thể khởi tạo Workmanager: $e');
  }

  // 4. Kiểm tra vai trò đã chọn trước đó
  final prefs = await SharedPreferences.getInstance();
  final savedRole = prefs.getString(RoleSelectionScreen.prefSelectedRole);

  Widget initialScreen;

  if (savedRole == 'elder') {
    // Chế độ Người cao tuổi: Kiểm tra trạng thái ghép đôi
    final isPaired = await ApiService.instance.isPaired();
    initialScreen = isPaired ? const SosButtonScreen() : const DevicePairingScreen();
  } else if (savedRole == 'caregiver') {
    // Chế độ Người thân: Kiểm tra đăng nhập JWT
    final isLoggedIn = await CaregiverApiService.instance.isLoggedIn();
    initialScreen = isLoggedIn ? const HomeScreen() : const LoginScreen();
  } else {
    // Chưa chọn vai trò -> Hiển thị Màn hình Chọn Vai Trò
    initialScreen = const RoleSelectionScreen();
  }

  runApp(CareAiUnifiedApp(initialScreen: initialScreen));
}

class CareAiUnifiedApp extends StatelessWidget {
  final Widget initialScreen;

  const CareAiUnifiedApp({super.key, required this.initialScreen});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'CareAI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF0284C7),
          primary: const Color(0xFF0284C7),
          secondary: const Color(0xFF0EA5E9),
          brightness: Brightness.light,
        ),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      home: initialScreen,
    );
  }
}

