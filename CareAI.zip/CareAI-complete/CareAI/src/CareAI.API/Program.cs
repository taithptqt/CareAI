using System.Text;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using CareAI.API.Middlewares;
using CareAI.Infrastructure.BackgroundWorkers;
using CareAI.Infrastructure.Data;
using CareAI.Infrastructure.Engines;
using CareAI.Infrastructure.AnomalyDetection;
using CareAI.Infrastructure.WeeklyReports;

var builder = WebApplication.CreateBuilder(args);

// Local Flutter web development only; production origins require explicit configuration.
if (builder.Environment.IsDevelopment())
{
    builder.Services.AddCors(options => options.AddPolicy("FlutterLocal", policy =>
        policy.WithOrigins("http://localhost:8080", "http://127.0.0.1:8080")
            .AllowAnyHeader()
            .AllowAnyMethod()));
}

// 1. CẤU HÌNH CƠ SỞ DỮ LIỆU SQL SERVER
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection") ??
    "Server=.\\SQLEXPRESS;Database=CareAiDb;Integrated Security=True;TrustServerCertificate=True;";

builder.Services.AddDbContext<CareAiDbContext>(options =>
    options.UseSqlServer(connectionString, sql =>
    {
        sql.EnableRetryOnFailure(maxRetryCount: 3, maxRetryDelay: TimeSpan.FromSeconds(5), errorNumbersToAdd: null);
    }));

// 2. CẤU HÌNH BỘ ĐỆM RAM CHỐNG OOM (LÁ CHẮN BẢO VỆ TÀI NGUYÊN)
builder.Services.AddMemoryCache(options =>
{
    options.SizeLimit = 50_000;
    options.CompactionPercentage = 0.20;
});

// 3. ĐĂNG KÝ CORE ENGINES
builder.Services.AddScoped<TelemetryEngine>();
builder.Services.AddScoped<ClinicalDiagnosticEngine>();

// 4. ĐĂNG KÝ HỆ THỐNG BACKGROUND WORKERS
builder.Services.AddHostedService<NotificationDispatcherWorker>();
builder.Services.AddHostedService<WatchdogBackgroundWorker>();
builder.Services.AddHostedService<DataRetentionBackgroundWorker>();
builder.Services.AddOptions<AnomalyDetectionOptions>()
    .Bind(builder.Configuration.GetSection("AnomalyDetection"))
    .Validate(o => o.Confidence > 0 && o.Confidence < 100, "Confidence must be between 0 and 100")
    .Validate(o => o.MinimumBaselineDays >= 2 && o.MinimumBaselineDays <= 13, "Baseline days must be 2–13")
    .Validate(o => double.IsFinite(o.MinimumUsualMorningSteps) && o.MinimumUsualMorningSteps > 0,
        "MinimumUsualMorningSteps must be positive")
    .Validate(o => TimeZoneInfo.TryFindSystemTimeZoneById(o.TimeZoneId, out _), "Invalid anomaly time zone")
    .ValidateOnStart();
builder.Services.AddSingleton<TimeSeriesAnomalyDetector>();
builder.Services.AddHostedService<AnomalyDetectionWorker>();
builder.Services.AddOptions<WeeklyReportOptions>()
    .Bind(builder.Configuration.GetSection("WeeklyReports"))
    .Validate(o => TimeZoneInfo.TryFindSystemTimeZoneById(o.TimeZoneId, out _), "Invalid weekly report time zone")
    .Validate(o => !string.IsNullOrWhiteSpace(o.GeminiModel), "GeminiModel is required")
    .ValidateOnStart();
builder.Services.AddOptions<ReportPushOptions>().Bind(builder.Configuration.GetSection("ReportPush"))
    .Validate(o => !o.Enabled || !string.IsNullOrWhiteSpace(o.ProjectId), "ReportPush ProjectId required when enabled")
    .ValidateOnStart();
builder.Services.AddSingleton<PiiAnonymizerService>();
builder.Services.AddSingleton<RuleBasedWeeklyReportFallbackEngine>();
builder.Services.AddHttpClient<GeminiWeeklyReportClient>(client =>
{
    client.Timeout = TimeSpan.FromSeconds(5);
    client.MaxResponseContentBufferSize = 128 * 1024;
});
builder.Services.AddScoped<WeeklyReportService>();
builder.Services.AddSingleton<IWeeklyReportPushSender, WeeklyReportPushSender>();
builder.Services.AddHostedService<WeeklyReportWorker>();
builder.Services.AddHostedService<WeeklyReportNotificationWorker>();

// 5. CẤU HÌNH XÁC THỰC JWT CHO NGƯỜI THÂN
var jwtSecret = builder.Configuration["Jwt:SecretKey"] ?? "REPLACE_WITH_YOUR_OWN_RANDOM_SECRET_AT_LEAST_32_BYTES";
var jwtIssuer = builder.Configuration["Jwt:Issuer"] ?? "CareAI.Server";
var jwtAudience = builder.Configuration["Jwt:Audience"] ?? "CareAI.CaregiverApp";

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
    .AddJwtBearer(options =>
    {
        options.TokenValidationParameters = new TokenValidationParameters
        {
            ValidateIssuer = true,
            ValidIssuer = jwtIssuer,
            ValidateAudience = true,
            ValidAudience = jwtAudience,
            ValidateIssuerSigningKey = true,
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwtSecret)),
            ValidateLifetime = true,
            ClockSkew = TimeSpan.FromMinutes(1)
        };
    });

builder.Services.AddAuthorization();

builder.Services.AddControllers();
builder.Services.AddHealthChecks();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "CareAI Sovereignty API", Version = "v111.0" });

    // Cấu hình JWT Bearer trong Swagger UI
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Description = "Nhập JWT Token: Bearer {token}",
        Name = "Authorization",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.ApiKey,
        Scheme = "Bearer"
    });

    c.AddSecurityRequirement(new OpenApiSecurityRequirement
    {
        {
            new OpenApiSecurityScheme
            {
                Reference = new OpenApiReference
                {
                    Type = ReferenceType.SecurityScheme,
                    Id = "Bearer"
                }
            },
            Array.Empty<string>()
        }
    });
});

var app = builder.Build();

app.UseRouting();
if (app.Environment.IsDevelopment())
{
    app.UseCors("FlutterLocal");
}

// 6. PIPELINE XỬ LÝ HTTP & SWAGGER
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "CareAI API v111.0");
    });
}

// Health check endpoints
app.MapHealthChecks("/health");
app.MapHealthChecks("/healthz");

// Middleware xác thực Token tĩnh của thiết bị phần cứng (X-DeviceId, X-Device-Token)
app.UseMiddleware<DeviceTokenAuthMiddleware>();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

// 7. TỰ ĐỘNG KHỞI TẠO CƠ SỞ DỮ LIỆU & SCHEMA IDEMPOTENT KHI KHỞI ĐỘNG
using (var scope = app.Services.CreateScope())
{
    var logger = scope.ServiceProvider.GetRequiredService<ILogger<Program>>();
    try
    {
        await DatabaseMigrationHelper.InitializeDatabaseAsync(connectionString, logger);
    }
    catch (Exception ex)
    {
        logger.LogError(ex, "[STARTUP-WARNING] Khởi tạo CSDL gặp lỗi. Tiếp tục chạy.");
    }
}

app.Run();


