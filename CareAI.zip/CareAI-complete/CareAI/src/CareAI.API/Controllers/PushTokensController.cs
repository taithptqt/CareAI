using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using CareAI.Core.Entities;
using CareAI.Infrastructure.Data;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CareAI.API.Controllers;

[ApiController, Authorize, Route("api/v1/caregivers/push-token")]
public sealed class PushTokensController(CareAiDbContext db) : ControllerBase
{
    public sealed record TokenRequest([Required, StringLength(500, MinimumLength = 10)] string Token);

    [HttpPut]
    public async Task<IActionResult> Register(TokenRequest request, CancellationToken ct)
    {
        var caregiverId = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (caregiverId is null) return Unauthorized();
        // Stable token ID lets a phone switch accounts without retaining the old subscription.
        var id = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(request.Token)))[..50];
        var token = await db.CaregiverPushTokens.FindAsync([id], ct);
        if (token is null)
        {
            token = new CaregiverPushToken { Id = id };
            db.CaregiverPushTokens.Add(token);
        }
        token.CaregiverId = caregiverId;
        token.PushToken = request.Token;
        token.IsActive = true;
        token.LastUsedAt = DateTime.UtcNow;
        token.DeactivatedAt = null;
        token.DeactivationReason = null;
        await db.SaveChangesAsync(ct);
        return NoContent();
    }

    [HttpDelete]
    public async Task<IActionResult> Remove(TokenRequest request, CancellationToken ct)
    {
        var id = User.FindFirstValue(ClaimTypes.NameIdentifier);
        if (id is null) return Unauthorized();
        var tokens = await db.CaregiverPushTokens.Where(t => t.CaregiverId == id && t.PushToken == request.Token).ToListAsync(ct);
        foreach (var token in tokens)
        {
            token.IsActive = false;
            token.DeactivatedAt = DateTime.UtcNow;
            token.DeactivationReason = "SIGNED_OUT";
        }
        await db.SaveChangesAsync(ct);
        return NoContent();
    }
}
