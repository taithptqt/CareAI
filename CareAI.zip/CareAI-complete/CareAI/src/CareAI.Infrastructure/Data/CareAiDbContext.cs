using Microsoft.EntityFrameworkCore;
using CareAI.Core.Entities;
using CareAI.Core.Enums;

namespace CareAI.Infrastructure.Data;

public class CareAiDbContext : DbContext
{
    public CareAiDbContext(DbContextOptions<CareAiDbContext> options) : base(options)
    {
    }

    public DbSet<ElderProfile> ElderProfiles => Set<ElderProfile>();
    public DbSet<DeviceRegistration> DeviceRegistrations => Set<DeviceRegistration>();
    public DbSet<Caregiver> Caregivers => Set<Caregiver>();
    public DbSet<ElderCaregiver> ElderCaregivers => Set<ElderCaregiver>();
    public DbSet<CaregiverPushToken> CaregiverPushTokens => Set<CaregiverPushToken>();
    public DbSet<Incident> Incidents => Set<Incident>();
    public DbSet<IncidentTimelineEvent> IncidentTimelineEvents => Set<IncidentTimelineEvent>();
    public DbSet<HealthMeasurement> HealthMeasurements => Set<HealthMeasurement>();
    public DbSet<HealthInsight> HealthInsights => Set<HealthInsight>();
    public DbSet<WeeklyHealthReport> WeeklyHealthReports => Set<WeeklyHealthReport>();
    public DbSet<WeeklyReportNotification> WeeklyReportNotifications => Set<WeeklyReportNotification>();
    public DbSet<NotificationOutbox> NotificationOutboxes => Set<NotificationOutbox>();
    public DbSet<ProcessedTelemetryLedger> ProcessedTelemetryLedgers => Set<ProcessedTelemetryLedger>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.Entity<WeeklyHealthReport>(b =>
        {
            b.ToTable("WeeklyHealthReports");
            b.HasKey(r => r.Id);
            b.Property(r => r.ElderProfileId).HasMaxLength(50).IsRequired();
            b.Property(r => r.Content).IsRequired();
            b.Property(r => r.Source).HasMaxLength(20).IsRequired();
            b.HasOne(r => r.ElderProfile).WithMany().HasForeignKey(r => r.ElderProfileId).OnDelete(DeleteBehavior.Cascade);
            b.HasIndex(r => new { r.ElderProfileId, r.WeekEndUtc }).IsUnique().HasDatabaseName("UIX_WeeklyHealthReports_Week");
        });
        modelBuilder.Entity<WeeklyReportNotification>(b =>
        {
            b.ToTable("WeeklyReportNotifications");
            b.HasKey(n => n.Id);
            b.Property(n => n.CaregiverPushTokenId).HasMaxLength(50).IsRequired();
            b.Property(n => n.Status).HasMaxLength(20).IsRequired();
            b.Property(n => n.RowVersion).IsRowVersion();
            b.HasOne(n => n.WeeklyHealthReport).WithMany().HasForeignKey(n => n.WeeklyHealthReportId).OnDelete(DeleteBehavior.Cascade);
            b.HasIndex(n => new { n.WeeklyHealthReportId, n.CaregiverPushTokenId }).IsUnique()
                .HasDatabaseName("UIX_WeeklyReportNotifications_Recipient");
            b.HasIndex(n => new { n.Status, n.NextAttemptUtc });
        });
        modelBuilder.Entity<HealthInsight>(b =>
        {
            b.ToTable("HealthInsights");
            b.HasKey(i => i.Id);
            b.Property(i => i.ElderProfileId).HasMaxLength(50).IsRequired();
            b.Property(i => i.DeviceId).HasMaxLength(50).IsRequired();
            b.Property(i => i.InsightType).HasMaxLength(50).IsRequired();
            b.Property(i => i.Description).HasMaxLength(1000).IsRequired();
            b.HasOne(i => i.ElderProfile).WithMany().HasForeignKey(i => i.ElderProfileId)
                .OnDelete(DeleteBehavior.Cascade);
            b.HasIndex(i => new { i.ElderProfileId, i.DeviceId, i.InsightType, i.WindowEndUtc })
                .IsUnique().HasDatabaseName("UIX_HealthInsights_Window");
        });

        // 1. ElderProfile
        modelBuilder.Entity<ElderProfile>(b =>
        {
            b.HasKey(e => e.Id);
            b.Property(e => e.FullName).HasMaxLength(100).IsRequired();
            b.Property(e => e.EmergencyContact).HasMaxLength(50);
            b.Property(e => e.PairingPin).HasMaxLength(10);
        });

        // 2. DeviceRegistration
        modelBuilder.Entity<DeviceRegistration>(b =>
        {
            b.HasKey(d => d.Id);
            b.Property(d => d.DeviceTokenHash).HasMaxLength(128).IsRequired();
            b.Property(d => d.DeviceType).HasMaxLength(50).IsRequired();
            b.Property(d => d.FirmwareVersion).HasMaxLength(50).HasDefaultValue("1.0.0");
            b.HasOne(d => d.ElderProfile)
                .WithMany(e => e.Devices)
                .HasForeignKey(d => d.ElderProfileId)
                .OnDelete(DeleteBehavior.Cascade);
            b.HasIndex(d => d.ElderProfileId);
            b.HasIndex(d => d.LastHeartbeat);
        });

        // 3. Caregiver
        modelBuilder.Entity<Caregiver>(b =>
        {
            b.HasKey(c => c.Id);
            b.Property(c => c.FullName).HasMaxLength(100).IsRequired();
            b.Property(c => c.PhoneNumber).HasMaxLength(20).IsRequired();
            b.Property(c => c.Email).HasMaxLength(100).IsRequired();
            b.HasIndex(c => c.Email).IsUnique();
        });

        // 4. ElderCaregiver
        modelBuilder.Entity<ElderCaregiver>(b =>
        {
            b.HasKey(ec => ec.Id);
            b.HasOne(ec => ec.ElderProfile)
                .WithMany(e => e.ElderCaregivers)
                .HasForeignKey(ec => ec.ElderProfileId)
                .OnDelete(DeleteBehavior.Cascade);
            b.HasOne(ec => ec.Caregiver)
                .WithMany(c => c.ElderCaregivers)
                .HasForeignKey(ec => ec.CaregiverId)
                .OnDelete(DeleteBehavior.Cascade);
            b.HasIndex(ec => new { ec.ElderProfileId, ec.CaregiverId }).IsUnique();
        });

        // 5. CaregiverPushToken
        modelBuilder.Entity<CaregiverPushToken>(b =>
        {
            b.HasKey(t => t.Id);
            b.Property(t => t.PushToken).HasMaxLength(500).IsRequired();
            b.HasOne(t => t.Caregiver)
                .WithMany(c => c.PushTokens)
                .HasForeignKey(t => t.CaregiverId)
                .OnDelete(DeleteBehavior.Cascade);
            b.HasIndex(t => new { t.CaregiverId, t.IsActive });
        });

        // 6. Incident & Filtered Unique Index UIX_Incidents_SingleActiveElder
        modelBuilder.Entity<Incident>(b =>
        {
            b.HasKey(i => i.Id);
            b.Property(i => i.EmergencyType).HasMaxLength(50).IsRequired();
            b.Property(i => i.Severity).HasConversion<int>().IsRequired();
            b.Property(i => i.Status).HasConversion<int>().IsRequired();
            b.Property(i => i.RowVersion).IsRowVersion();

            b.HasOne(i => i.ElderProfile)
                .WithMany(e => e.Incidents)
                .HasForeignKey(i => i.ElderProfileId)
                .OnDelete(DeleteBehavior.Cascade);

            // BẤT BIẾN KỸ THUẬT: Filtered Unique Index chỉ cho phép duy nhất 1 sự cố Active (Open hoặc Acknowledged)
            b.HasIndex(i => i.ElderProfileId)
                .HasDatabaseName("UIX_Incidents_SingleActiveElder")
                .IsUnique()
                .HasFilter("[Status] IN (1, 2)"); // Open = 1, Acknowledged = 2
        });

        // 7. IncidentTimelineEvent
        modelBuilder.Entity<IncidentTimelineEvent>(b =>
        {
            b.HasKey(t => t.Id);
            b.Property(t => t.EventType).HasMaxLength(50).IsRequired();
            b.HasOne(t => t.Incident)
                .WithMany(i => i.TimelineEvents)
                .HasForeignKey(t => t.IncidentId)
                .OnDelete(DeleteBehavior.Cascade);
            b.HasIndex(t => t.IncidentId);
        });

        // 8. HealthMeasurement & Deduplication Index
        modelBuilder.Entity<HealthMeasurement>(b =>
        {
            b.HasKey(m => m.Id);
            b.Property(m => m.Id).ValueGeneratedOnAdd();
            b.Property(m => m.MetricType).HasMaxLength(50).IsRequired();
            b.Property(m => m.Unit).HasMaxLength(20).IsRequired();

            b.HasOne(m => m.ElderProfile)
                .WithMany(e => e.Measurements)
                .HasForeignKey(m => m.ElderProfileId)
                .OnDelete(DeleteBehavior.Cascade);

            // BẤT BIẾN ĐA THIẾT BỊ: Khử trùng lặp trên cùng 1 thiết bị đo cùng 1 thời điểm
            b.HasIndex(m => new { m.ElderProfileId, m.DeviceId, m.Timestamp, m.MetricType })
                .HasDatabaseName("UIX_HealthMeasurements_Deduplication")
                .IsUnique();

            b.HasIndex(m => new { m.ElderProfileId, m.MetricType, m.Timestamp });
        });

        // 9. NotificationOutbox
        modelBuilder.Entity<NotificationOutbox>(b =>
        {
            b.HasKey(n => n.Id);
            b.Property(n => n.Status).HasMaxLength(20).HasDefaultValue("PENDING");
            b.HasOne(n => n.Incident)
                .WithMany()
                .HasForeignKey(n => n.IncidentId)
                .OnDelete(DeleteBehavior.Cascade);
            b.HasIndex(n => new { n.Status, n.NextRetryAt });
        });

        // 10. ProcessedTelemetryLedger (Khóa chính kép)
        modelBuilder.Entity<ProcessedTelemetryLedger>(b =>
        {
            b.HasKey(p => new { p.DeviceId, p.PacketId })
                .HasName("PK_ProcessedTelemetryLedgers");
            b.HasIndex(p => p.ReceivedAt);
        });
    }
}
